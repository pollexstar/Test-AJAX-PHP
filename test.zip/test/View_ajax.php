<?php
	include 'database.php';
	$sql = "SELECT * FROM formdata";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
?>	
		<tr>
			<td><?=$row['name'];?></td>
			<td><?=$row['city'];?></td>
			<td><?=$row['occupation'];?></td>
					</tr>
<?php	
	}
	}
	else {
		echo "0 results";
	}
	mysqli_close($conn);
?>